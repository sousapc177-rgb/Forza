package com.mission.openworld

import android.content.Context
import android.opengl.GLSurfaceView

class GameView(context: Context) : GLSurfaceView(context) {
    private val gameRenderer = GameRenderer(context)

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 24, 0)
        preserveEGLContextOnPause = true
        setRenderer(gameRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }
}
