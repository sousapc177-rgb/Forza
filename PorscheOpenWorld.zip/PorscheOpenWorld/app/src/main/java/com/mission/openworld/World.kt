package com.mission.openworld

class Rng(seed: Long) {
    private var s: Long = seed xor 0x5DEECE66DL

    init {
        next()
        next()
    }

    fun next(): Float {
        s = s * 6364136223846793005L + 1442695040888963407L
        return ((s ushr 40) and 0xFFFFFFL).toInt() / 16777216f
    }

    fun range(a: Float, b: Float): Float = a + (b - a) * next()
}

class Building(
    val minX: Float, val minZ: Float, val maxX: Float, val maxZ: Float,
    val h: Float, val r: Float, val g: Float, val b: Float
)

class Tree(val x: Float, val z: Float, val s: Float)

class Block(val buildings: List<Building>, val trees: List<Tree>)

object World {
    const val BLOCK = 150f
    const val ROAD = 16f
    private const val MARGIN = 3f

    private val cache = HashMap<Long, Block>()

    private val PALETTE = arrayOf(
        floatArrayOf(0.62f, 0.64f, 0.68f),
        floatArrayOf(0.78f, 0.74f, 0.66f),
        floatArrayOf(0.55f, 0.60f, 0.70f),
        floatArrayOf(0.72f, 0.52f, 0.46f),
        floatArrayOf(0.45f, 0.48f, 0.52f),
        floatArrayOf(0.85f, 0.85f, 0.82f),
        floatArrayOf(0.40f, 0.55f, 0.58f)
    )

    fun block(i: Int, j: Int): Block {
        val key = (i.toLong() shl 32) xor (j.toLong() and 0xFFFFFFFFL)
        val c = cache[key]
        if (c != null) return c
        if (cache.size > 500) cache.clear()
        val b = generate(i, j)
        cache[key] = b
        return b
    }

    private fun mk(minX: Float, minZ: Float, maxX: Float, maxZ: Float, h: Float, rng: Rng): Building {
        val idx = (rng.next() * PALETTE.size).toInt().coerceIn(0, PALETTE.size - 1)
        val p = PALETTE[idx]
        return Building(minX, minZ, maxX, maxZ, h, p[0], p[1], p[2])
    }

    private fun generate(i: Int, j: Int): Block {
        val rng = Rng(i * 73856093L xor j * 19349663L)
        val x0 = i * BLOCK + ROAD + MARGIN
        val z0 = j * BLOCK + ROAD + MARGIN
        val size = BLOCK - ROAD - 2f * MARGIN
        val bl = ArrayList<Building>()
        val tr = ArrayList<Tree>()
        val kind = rng.next()

        if (kind < 0.16f) {
            for (k in 0 until 30) {
                tr.add(Tree(x0 + rng.range(4f, size - 4f), z0 + rng.range(4f, size - 4f), rng.range(0.8f, 1.5f)))
            }
        } else if (kind < 0.5f) {
            val w = size * rng.range(0.55f, 0.92f)
            val d = size * rng.range(0.55f, 0.92f)
            val cx = x0 + size / 2f
            val cz = z0 + size / 2f
            bl.add(mk(cx - w / 2f, cz - d / 2f, cx + w / 2f, cz + d / 2f, rng.range(25f, 95f), rng))
        } else if (kind < 0.86f) {
            val cell = size / 2f
            for (a in 0..1) {
                for (c in 0..1) {
                    val w = cell * rng.range(0.6f, 0.88f)
                    val d = cell * rng.range(0.6f, 0.88f)
                    val cx = x0 + cell * (a + 0.5f)
                    val cz = z0 + cell * (c + 0.5f)
                    bl.add(mk(cx - w / 2f, cz - d / 2f, cx + w / 2f, cz + d / 2f, rng.range(10f, 62f), rng))
                }
            }
        } else {
            for (k in 0 until 3) {
                val w = size * rng.range(0.2f, 0.35f)
                val d = size * rng.range(0.2f, 0.35f)
                val cx = x0 + rng.range(w / 2f + 2f, size - w / 2f - 2f)
                val cz = z0 + rng.range(d / 2f + 2f, size - d / 2f - 2f)
                bl.add(mk(cx - w / 2f, cz - d / 2f, cx + w / 2f, cz + d / 2f, rng.range(6f, 30f), rng))
            }
            for (k in 0 until 8) {
                tr.add(Tree(x0 + rng.range(3f, size - 3f), z0 + rng.range(3f, size - 3f), rng.range(0.8f, 1.3f)))
            }
        }
        return Block(bl, tr)
    }
}
