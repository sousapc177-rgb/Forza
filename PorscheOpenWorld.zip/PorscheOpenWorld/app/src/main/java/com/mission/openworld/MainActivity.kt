package com.mission.openworld

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var glView: GameView
    private lateinit var speedText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var sound: EngineSound? = null

    private val ticker = object : Runnable {
        override fun run() {
            speedText.text = GameInput.speedKmh.toString() + " km/h"
            sound?.update(GameInput.enginePitch, GameInput.engineVol)
            handler.postDelayed(this, 50)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, gravity: Int, l: Int, t: Int, r: Int, b: Int): FrameLayout.LayoutParams {
        val p = FrameLayout.LayoutParams(dp(w), dp(h), gravity)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    private fun makeButton(label: String, textSize: Float, onChange: (Boolean) -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.textSize = textSize
        tv.typeface = Typeface.DEFAULT_BOLD
        val bg = GradientDrawable()
        bg.setColor(Color.argb(120, 15, 15, 25))
        bg.cornerRadius = dp(18).toFloat()
        bg.setStroke(dp(2), Color.argb(170, 255, 255, 255))
        tv.background = bg
        tv.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.55f
                    onChange(true)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = 1f
                    onChange(false)
                }
            }
            true
        }
        return tv
    }

    @Suppress("DEPRECATION")
    private fun goImmersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val root = FrameLayout(this)
        glView = GameView(this)
        root.addView(glView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // velocimetro
        speedText = TextView(this)
        speedText.text = "0 km/h"
        speedText.textSize = 30f
        speedText.setTextColor(Color.WHITE)
        speedText.typeface = Typeface.DEFAULT_BOLD
        speedText.setShadowLayer(8f, 0f, 2f, Color.BLACK)
        speedText.gravity = Gravity.CENTER
        root.addView(speedText, lp(200, 50, Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, 8, 0, 0))

        // direcao (esquerda embaixo)
        root.addView(makeButton("<", 34f) { GameInput.steerLeft = it },
            lp(95, 95, Gravity.BOTTOM or Gravity.START, 24, 0, 0, 24))
        root.addView(makeButton(">", 34f) { GameInput.steerRight = it },
            lp(95, 95, Gravity.BOTTOM or Gravity.START, 130, 0, 0, 24))

        // pedais (direita embaixo)
        root.addView(makeButton("ACELERAR", 15f) { GameInput.gas = it },
            lp(120, 130, Gravity.BOTTOM or Gravity.END, 0, 0, 24, 24))
        root.addView(makeButton("FREIO / RÉ", 13f) { GameInput.brake = it },
            lp(100, 95, Gravity.BOTTOM or Gravity.END, 0, 0, 156, 24))
        root.addView(makeButton("DRIFT", 14f) { GameInput.handbrake = it },
            lp(100, 52, Gravity.BOTTOM or Gravity.END, 0, 0, 156, 130))

        // botoes de cima
        root.addView(makeButton("CÂMERA", 12f) { if (it) GameInput.cameraRequest = true },
            lp(80, 42, Gravity.TOP or Gravity.END, 0, 10, 10, 0))
        root.addView(makeButton("COR", 12f) { if (it) GameInput.colorRequest = true },
            lp(64, 42, Gravity.TOP or Gravity.END, 0, 10, 98, 0))
        root.addView(makeButton("VOLTAR", 12f) { if (it) GameInput.resetRequest = true },
            lp(80, 42, Gravity.TOP or Gravity.END, 0, 10, 170, 0))

        setContentView(root)
        goImmersive()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goImmersive()
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
        val s = EngineSound()
        s.start()
        sound = s
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        sound?.stop()
        sound = null
        GameInput.releaseAll()
        glView.onPause()
    }
}
