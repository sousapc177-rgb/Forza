package com.mission.openworld

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES30
import android.opengl.GLUtils
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class Mesh(val vbo: Int, val ibo: Int, val count: Int)

object Gfx {

    fun upload(vb: FloatBuffer, floats: Int, ib: IntBuffer, indices: Int): Mesh {
        val ids = IntArray(2)
        GLES30.glGenBuffers(2, ids, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, ids[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, floats * 4, vb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ids[1])
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, indices * 4, ib, GLES30.GL_STATIC_DRAW)
        return Mesh(ids[0], ids[1], indices)
    }

    fun make(verts: FloatArray, idx: IntArray): Mesh {
        val vb = ByteBuffer.allocateDirect(verts.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        vb.put(verts)
        vb.position(0)
        val ib = ByteBuffer.allocateDirect(idx.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer()
        ib.put(idx)
        ib.position(0)
        return upload(vb, verts.size, ib, idx.size)
    }

    // layout: pos(3) normal(3) uv(2) = 32 bytes
    fun draw(m: Mesh) {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, m.vbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, m.ibo)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, m.count, GLES30.GL_UNSIGNED_INT, 0)
    }

    fun loadTexture(ctx: Context, path: String): Int {
        val bmp = BitmapFactory.decodeStream(ctx.assets.open(path)) ?: return 0
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, ids[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        bmp.recycle()
        return ids[0]
    }

    // ---------- formas simples ----------

    private fun addQuad(v: ArrayList<Float>, ix: ArrayList<Int>, p: Array<FloatArray>, n: FloatArray) {
        val base = v.size / 8
        val uvs = arrayOf(
            floatArrayOf(0f, 0f), floatArrayOf(1f, 0f),
            floatArrayOf(1f, 1f), floatArrayOf(0f, 1f)
        )
        for (k in 0 until 4) {
            v.add(p[k][0]); v.add(p[k][1]); v.add(p[k][2])
            v.add(n[0]); v.add(n[1]); v.add(n[2])
            v.add(uvs[k][0]); v.add(uvs[k][1])
        }
        ix.add(base); ix.add(base + 1); ix.add(base + 2)
        ix.add(base); ix.add(base + 2); ix.add(base + 3)
    }

    // cubo: x,z de -0.5 a 0.5 ; y de 0 a 1
    fun cube(): Mesh {
        val v = ArrayList<Float>()
        val ix = ArrayList<Int>()
        addQuad(v, ix, arrayOf(
            floatArrayOf(-0.5f, 1f, -0.5f), floatArrayOf(0.5f, 1f, -0.5f),
            floatArrayOf(0.5f, 1f, 0.5f), floatArrayOf(-0.5f, 1f, 0.5f)
        ), floatArrayOf(0f, 1f, 0f))
        addQuad(v, ix, arrayOf(
            floatArrayOf(0.5f, 0f, -0.5f), floatArrayOf(0.5f, 0f, 0.5f),
            floatArrayOf(0.5f, 1f, 0.5f), floatArrayOf(0.5f, 1f, -0.5f)
        ), floatArrayOf(1f, 0f, 0f))
        addQuad(v, ix, arrayOf(
            floatArrayOf(-0.5f, 0f, 0.5f), floatArrayOf(-0.5f, 0f, -0.5f),
            floatArrayOf(-0.5f, 1f, -0.5f), floatArrayOf(-0.5f, 1f, 0.5f)
        ), floatArrayOf(-1f, 0f, 0f))
        addQuad(v, ix, arrayOf(
            floatArrayOf(0.5f, 0f, 0.5f), floatArrayOf(-0.5f, 0f, 0.5f),
            floatArrayOf(-0.5f, 1f, 0.5f), floatArrayOf(0.5f, 1f, 0.5f)
        ), floatArrayOf(0f, 0f, 1f))
        addQuad(v, ix, arrayOf(
            floatArrayOf(-0.5f, 0f, -0.5f), floatArrayOf(0.5f, 0f, -0.5f),
            floatArrayOf(0.5f, 1f, -0.5f), floatArrayOf(-0.5f, 1f, -0.5f)
        ), floatArrayOf(0f, 0f, -1f))
        return make(v.toFloatArray(), ix.toIntArray())
    }

    // cone: raio 1 na base (y=0), ponta em y=1
    fun cone(): Mesh {
        val seg = 10
        val v = ArrayList<Float>()
        val ix = ArrayList<Int>()
        for (k in 0 until seg) {
            val a0 = (2.0 * PI * k / seg).toFloat()
            val a1 = (2.0 * PI * (k + 1) / seg).toFloat()
            val am = (a0 + a1) * 0.5f
            var nx = cos(am)
            var ny = 0.45f
            var nz = sin(am)
            val len = sqrt(nx * nx + ny * ny + nz * nz)
            nx /= len; ny /= len; nz /= len
            val base = v.size / 8
            // ponta
            v.add(0f); v.add(1f); v.add(0f); v.add(nx); v.add(ny); v.add(nz); v.add(0.5f); v.add(1f)
            v.add(cos(a0)); v.add(0f); v.add(sin(a0)); v.add(nx); v.add(ny); v.add(nz); v.add(0f); v.add(0f)
            v.add(cos(a1)); v.add(0f); v.add(sin(a1)); v.add(nx); v.add(ny); v.add(nz); v.add(1f); v.add(0f)
            ix.add(base); ix.add(base + 1); ix.add(base + 2)
        }
        return make(v.toFloatArray(), ix.toIntArray())
    }

    // quadrado no chao de -1 a 1 (xz), com uv 0..1
    fun quad(): Mesh {
        val v = ArrayList<Float>()
        val ix = ArrayList<Int>()
        addQuad(v, ix, arrayOf(
            floatArrayOf(-1f, 0f, -1f), floatArrayOf(1f, 0f, -1f),
            floatArrayOf(1f, 0f, 1f), floatArrayOf(-1f, 0f, 1f)
        ), floatArrayOf(0f, 1f, 0f))
        return make(v.toFloatArray(), ix.toIntArray())
    }

    fun sphere(): Mesh {
        val lat = 12
        val lon = 20
        val v = ArrayList<Float>()
        val ix = ArrayList<Int>()
        for (i in 0..lat) {
            val phi = (PI * i / lat).toFloat()
            for (j in 0..lon) {
                val th = (2.0 * PI * j / lon).toFloat()
                val x = sin(phi) * cos(th)
                val y = cos(phi)
                val z = sin(phi) * sin(th)
                v.add(x); v.add(y); v.add(z)
                v.add(x); v.add(y); v.add(z)
                v.add(j.toFloat() / lon); v.add(i.toFloat() / lat)
            }
        }
        for (i in 0 until lat) {
            for (j in 0 until lon) {
                val a = i * (lon + 1) + j
                val b = a + lon + 1
                ix.add(a); ix.add(b); ix.add(a + 1)
                ix.add(a + 1); ix.add(b); ix.add(b + 1)
            }
        }
        return make(v.toFloatArray(), ix.toIntArray())
    }
}
